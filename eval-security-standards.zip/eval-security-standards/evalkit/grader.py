"""Deterministic answer grading. Models are told to finish with 'FINAL ANSWER: <value>'."""
from __future__ import annotations

import re

from evalkit.schema import Question

FINAL = re.compile(r"FINAL\s+ANSWER\s*:\s*(.+)", re.I)
NUM = re.compile(r"[-+]?\d[\d,]*\.?\d*(?:[eE][-+]?\d+)?")
SPLIT = re.compile(r"\s*(?:,|;|<|>|\n|\s->\s)\s*")


def extract(response: str) -> str:
    """Take the text after the LAST 'FINAL ANSWER:'; fall back to the last non-empty line."""
    found = FINAL.findall(response or "")
    if found:
        return found[-1].strip()
    lines = [l for l in (response or "").strip().splitlines() if l.strip()]
    return lines[-1].strip() if lines else ""


def norm(s) -> str:
    """Lower-case, unify dashes, drop whitespace/quotes/trailing punctuation. Leading zeros are preserved."""
    s = str(s).lower().replace("–", "-").replace("—", "-").replace("−", "-")
    s = re.sub(r"[\s\"'`*_]", "", s)
    return s.rstrip(".,;")


def parse_number(text: str):
    m = NUM.search(str(text).replace("−", "-"))
    return float(m.group(0).replace(",", "")) if m else None


def grade(q: Question, response: str) -> bool:
    got = extract(response)
    if q.answer_type == "number":
        val = parse_number(got)
        return val is not None and abs(val - float(q.answer)) <= q.tolerance + 1e-9
    if q.answer_type == "text":
        options = [q.answer, *q.accept]
        return norm(got) in {norm(o) for o in options}
    parts = [norm(x) for x in SPLIT.split(got) if x.strip()]
    key = [norm(x) for x in q.answer]
    return parts == key if q.answer_type == "ordered_list" else sorted(parts) == sorted(key)


def fmt_answer(answer) -> str:
    return ", ".join(map(str, answer)) if isinstance(answer, (list, tuple)) else str(answer)
