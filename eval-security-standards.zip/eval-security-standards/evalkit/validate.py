"""Audit a question set: lint, recompute every answer with independent code, and check that the shortcut fails.

  python -m evalkit.validate questions/questions.jsonl          # run from the repo root (imports ./verifiers.py)
  python -m evalkit.validate questions/questions.jsonl --check-links   # optional: HEAD-check source URLs (network)
Exit code 1 if any item fails.
"""
from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path

from evalkit.grader import fmt_answer, grade
from evalkit.schema import lint, load_questions


def audit(path, verifiers_module: str = "verifiers") -> list[str]:
    sys.path.insert(0, str(Path.cwd()))
    expected = importlib.import_module(verifiers_module).EXPECTED
    problems, seen = [], set()
    for q in load_questions(path):
        problems += [f"{q.id}: {m}" for m in lint(q, seen)]
        if q.verifier:
            if q.verifier not in expected:
                problems.append(f"{q.id}: verifier '{q.verifier}' not found in {verifiers_module}.EXPECTED")
                continue
            recomputed = expected[q.verifier]()
            if not grade(q, f"FINAL ANSWER: {fmt_answer(recomputed)}"):
                problems.append(f"{q.id}: answer key {q.answer!r} != independently recomputed {recomputed!r}")
        if grade(q, f"FINAL ANSWER: {fmt_answer(q.naive_answer)}"):
            problems.append(f"{q.id}: the documented shortcut answer is graded CORRECT - item does not discriminate")
        if not grade(q, f"FINAL ANSWER: {fmt_answer(q.answer)}"):
            problems.append(f"{q.id}: the answer key does not grade as correct under its own rules")
    return problems


def check_links(path) -> list[str]:
    import urllib.request
    bad = []
    for q in load_questions(path):
        for s in q.sources:
            if s.get("url"):
                try:
                    urllib.request.urlopen(urllib.request.Request(s["url"], method="HEAD"), timeout=15)
                except Exception as e:  # network errors are reported, not fatal to logic checks
                    bad.append(f"{q.id}: {s['url']} -> {e}")
    return bad


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("questions")
    ap.add_argument("--verifiers", default="verifiers")
    ap.add_argument("--check-links", action="store_true")
    a = ap.parse_args(argv)
    problems = audit(a.questions, a.verifiers) + (check_links(a.questions) if a.check_links else [])
    n = len(load_questions(a.questions))
    print(f"{n} questions audited; {len(problems)} problem(s)")
    for p in problems:
        print(" -", p)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
