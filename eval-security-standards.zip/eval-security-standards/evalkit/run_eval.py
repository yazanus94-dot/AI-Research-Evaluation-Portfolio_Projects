"""Run a question set against a model and flag items that are too easy (candidates for hardening).

  python -m evalkit.run_eval --questions questions/questions.jsonl --model openai:gpt-4o --attempts 3
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from evalkit.grader import extract, grade
from evalkit.llm import get_model
from evalkit.schema import load_questions


def run(questions_path, model_spec: str, attempts: int = 3, too_easy: float = 0.67, only=None, out_dir="reports") -> dict:
    model = get_model(model_spec)
    rows = []
    for q in load_questions(questions_path):
        if only and q.id not in only:
            continue
        passes, answers = 0, []
        for _ in range(attempts):
            resp = model.respond(q)
            ok = grade(q, resp)
            passes += ok
            answers.append({"extracted": extract(resp), "correct": ok})
        rate = passes / attempts
        rows.append({"id": q.id, "topic": q.topic, "pass_rate": round(rate, 3), "too_easy": rate >= too_easy, "attempts": answers})
    summary = {
        "model": model.name, "attempts": attempts, "too_easy_threshold": too_easy,
        "run_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "overall_pass_rate": round(sum(r["pass_rate"] for r in rows) / max(1, len(rows)), 3),
        "flagged_too_easy": [r["id"] for r in rows if r["too_easy"]], "items": rows,
    }
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    safe = model.name.replace(":", "_").replace("/", "_")
    (out / f"results_{safe}.json").write_text(json.dumps(summary, indent=2))
    md = [f"# Results: {model.name}", "", f"Overall pass rate: **{summary['overall_pass_rate']:.0%}** ({attempts} attempts/item). "
          f"Items at or above {too_easy:.0%} are flagged for hardening.", "", "| ID | Topic | Pass rate | Flag |", "|---|---|---|---|"]
    md += [f"| {r['id']} | {r['topic']} | {r['pass_rate']:.0%} | {'too easy' if r['too_easy'] else ''} |" for r in rows]
    (out / f"results_{safe}.md").write_text("\n".join(md) + "\n")
    return summary


def main(argv=None) -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--questions", default="questions/questions.jsonl")
    ap.add_argument("--model", required=True)
    ap.add_argument("--attempts", type=int, default=3)
    ap.add_argument("--too-easy", type=float, default=0.67)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--out", default="reports")
    a = ap.parse_args(argv)
    s = run(a.questions, a.model, a.attempts, a.too_easy, a.only, a.out)
    print(f"{s['model']}: overall {s['overall_pass_rate']:.0%}; too easy: {s['flagged_too_easy'] or 'none'}")


if __name__ == "__main__":
    main()
