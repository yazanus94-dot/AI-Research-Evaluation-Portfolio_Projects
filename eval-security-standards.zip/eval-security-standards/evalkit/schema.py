"""Question schema + linting rules (the 'quality bar' every item must clear before it is accepted)."""
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path

ANSWER_TYPES = {"number", "text", "list", "ordered_list"}
VERIFICATION = {"code", "source", "both"}
HEDGES = re.compile(r"\b(usually|typically|generally|roughly|approximately|some|(?<!how )many|several|best|good|often|probably|about)\b", re.I)
PRECISION = re.compile(r"(decimal|nearest|integer|whole number|percentage|single word|comma|exactly|digits|MiB|ms\b|Hz\b|dB)", re.I)


@dataclass
class Question:
    id: str
    domain: str
    topic: str
    question: str
    answer: object
    answer_type: str                      # number | text | list | ordered_list
    rationale: str                        # step-by-step reasoning that justifies the key
    shortcut_trap: str                    # the tempting wrong approach this item is designed to catch
    naive_answer: object                  # what that wrong approach produces (must differ from `answer`)
    verification: str = "code"            # code | source | both
    verifier: str | None = None           # name of the function in verifiers.py that recomputes the answer
    sources: list = field(default_factory=list)   # [{"title":..., "locator":..., "url":... (optional)}]
    tolerance: float = 0.0                # numeric tolerance (absolute)
    accept: list = field(default_factory=list)    # extra accepted spellings for text answers
    tags: list = field(default_factory=list)
    measured_pass_rate: dict = field(default_factory=dict)   # filled by run_eval, e.g. {"openai:gpt-4o": 0.33}

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)


def load_questions(path) -> list[Question]:
    out = []
    for n, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        if line.strip() and not line.lstrip().startswith("#"):
            try:
                out.append(Question(**json.loads(line)))
            except (TypeError, json.JSONDecodeError) as e:
                raise ValueError(f"{path}:{n}: {e}") from e
    return out


def lint(q: Question, seen_ids: set[str] | None = None) -> list[str]:
    """Return a list of problems (empty list = item passes the quality bar)."""
    p = []
    if seen_ids is not None:
        if q.id in seen_ids:
            p.append("duplicate id")
        seen_ids.add(q.id)
    if not re.fullmatch(r"[A-Z]{1,3}\d{2,3}", q.id):
        p.append("id must look like A01 / SEC01")
    if q.answer_type not in ANSWER_TYPES:
        p.append(f"answer_type must be one of {sorted(ANSWER_TYPES)}")
    if q.verification not in VERIFICATION:
        p.append(f"verification must be one of {sorted(VERIFICATION)}")
    if len(q.question) < 60 or len(q.question) > 900:
        p.append("question length should be 60-900 characters")
    if HEDGES.search(q.question):
        p.append(f"ambiguous hedge word in question: {HEDGES.search(q.question).group(0)!r}")
    if q.answer_type == "number" and not PRECISION.search(q.question):
        p.append("numeric question must state units or required precision/rounding")
    if q.answer_type == "number" and q.tolerance <= 0:
        p.append("numeric question needs a tolerance > 0 consistent with the stated rounding")
    if len(q.rationale) < 60:
        p.append("rationale too short (explain the reasoning, not just the result)")
    if not q.shortcut_trap or q.naive_answer in (None, ""):
        p.append("shortcut_trap and naive_answer are required (what would a lazy solver answer?)")
    if str(q.naive_answer).strip().lower() == str(q.answer).strip().lower():
        p.append("naive_answer must differ from the correct answer")
    if q.verification in ("code", "both") and not q.verifier:
        p.append("verification includes code but no verifier function is named")
    if q.verification in ("source", "both"):
        if not q.sources:
            p.append("verification includes source but sources is empty")
    for s in q.sources:
        if not s.get("title") or not s.get("locator"):
            p.append("each source needs a title and a precise locator (section/page/table)")
    if q.verification == "source" and not q.sources:
        p.append("source-verified items must cite at least one source")
    return p
